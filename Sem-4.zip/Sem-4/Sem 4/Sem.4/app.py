from flask import Flask, request, send_file, render_template
from fpdf import FPDF
import os

app = Flask(__name__)

def image_to_pdf(image_path, pdf_path):
    pdf = FPDF()
    pdf.add_page()
    pdf.image(image_path, x=0, y=0, w=210, h=297)
    pdf.output(pdf_path, "F")

@app.route('/')
def upload_form():
    return render_template('upload.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return 'No file part'
    file = request.files['file']
    if file.filename == '':
        return 'No selected file'
    if file:
        image_path = os.path.join('uploads', file.filename)
        pdf_path = os.path.join('uploads', 'output_pdf.pdf')
        file.save(image_path)
        image_to_pdf(image_path, pdf_path)
        return send_file(pdf_path, as_attachment=True)

if __name__ == "__main__":
    if not os.path.exists('uploads'):
        os.makedirs('uploads')
    app.run(debug=True)




    
