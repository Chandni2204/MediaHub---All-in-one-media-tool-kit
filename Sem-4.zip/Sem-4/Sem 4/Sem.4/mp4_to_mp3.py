from moviepy.editor import *

# Load the mp4 file
video = VideoFileClip("Shri-Krishna-Govind-Hare-Murari-Bhakti-Song-Status-Videos.mp4")

# Extract audio from video
video.audio.write_audiofile("example.mp3")